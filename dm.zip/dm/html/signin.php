<?php
$a="111123454434231uiwkdvcn hvnmcusix7f678c9999cvcv8vxc";
echo'<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=div, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Login page</title>
</head>
<body>
    <div class="login_body">
        <img class="di" src="../images/dorm_icon.png" alt="">
        <div class="login_box">
            <img class="dlogo" src="../images/dorm_no_bg.png" alt="">
            <div class="user_info">
                <!-- <img class="user_info_img" src="../images/dp_grey.png" alt=""> -->
                <input type="text" placeholder="username">
            </div>
            <div class="user_info">
                <!-- <img class="user_info_img" src="../images/key_black.svg" alt=""> -->
                <input type="text" placeholder="password">
            </div>
            <a href="../html/study_tools.html">
                <button class="signin">Sign in</button>
            </a>
            <hr> 
            <!-- <div class="rule"></div> -->
            <p>Dont have an account yet. 
                <a href="../html/signup.html">
                    <span class="signup_link" style="cursor: pointer; color: var(--dormblue);">
                        Click here
                    </span>
                </a>
            </p>
        </div>
    </div>
</body>
</html> '; 
?>