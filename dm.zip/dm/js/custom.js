function showmenu(){

    openMbtn = document.getElementById('openMbtn');
    con = document.getElementById('con');
   

    openMbtn.style.top = '7vh';
    con.style.top = '20vh';
    
}
