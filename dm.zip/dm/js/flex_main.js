

let com_btn = document.querySelector('.msg')
let com = document.querySelector('.comment')

com_btn.addEventListener('click',()=>{
    if(com.style.display===""){
            com.style.display="block";
     }
    else{
         com.style.display="";
    }
})







