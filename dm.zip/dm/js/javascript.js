function more() {
	menu2 = document.getElementById('menu2');

	menu2.style.left = "8vw";
}

function closemore() {
	menu2 = document.getElementById('menu2');

	menu2.style.left = "-3vw";
}

// function more() {
// 	menu2 = document.getElementById('menu2');

// 	menu2.style.left = "8vw";
// }


function closemore() {
	menu2 = document.getElementById('menu2');

	menu2.style.left = "-3vw";
}

function level1(){
	level = document.getElementById('lvl');
	depart = document.getElementById('dept');

	level.style.display = "none";
	depart.style.display = "block";
}

function openMenu(){
	menu = document.getElementById(mb);

	mb.style.display = "block";
}


function closeMenu(){
	menu = document.getElementById(mb);

	mb.style.display = "none";
}


function more() {
	menu2 = document.getElementById('menu2');

	menu2.style.left = "8vw";
}

function closemore() {
	menu2 = document.getElementById('menu2');

	menu2.style.left = "-3vw";
}

function more() {
	menu2 = document.getElementById('menu2');

	menu2.style.left = "8vw";
}


function closemore() {
	menu2 = document.getElementById('menu2');

	menu2.style.left = "-3vw";
}

function level1(){
	level = document.getElementById('lvl');
	depart = document.getElementById('dept');

	level.style.display = "none";
	depart.style.display = "block";
}

function openMenu(){
	menu = document.getElementById(mb);

	mb.style.display = "block";
}


function closeMenu(){
	menu = document.getElementById(mb);

	mb.style.display = "none";
}



