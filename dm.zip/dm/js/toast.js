function snackbar(message) {
document.getElementById("snackbar").innerHTML=message;
  var x = document.getElementById("snackbar");
  x.className = "show";
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}

function toast(message) {
document.getElementById("snackbar").innerHTML=message;
  var x = document.getElementById("snackbar");
  x.className = "show";
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
